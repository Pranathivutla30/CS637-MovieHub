<nav>
    <ul>
        <li><a href="/movie/index.php?action=movies">Home</a></li>
        <li><a href="/movie/index.php?action=discussion">Discussion</a></li>
        <li><a href="/movie/app/views/statistic.php">Statistic</a></li>
        <li><a href="http://localhost:5000/form">Getting bored?</a></li>
    </ul>
    <form method="post" action="logout.php" style="margin: 0;">
        <button type="submit" class="logout-btn">Log out</button>
    </form>
</nav>