    <footer>
        <p>&copy; 2024 MovieWorld</p>
    </footer>
</body>
</html>