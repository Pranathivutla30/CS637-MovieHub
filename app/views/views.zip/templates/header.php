<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Site</title>
    <link rel="stylesheet" href="/movie/public/assets/css/style.css">
    <style>
    nav { background-color: #333; padding: 10px; display: flex; justify-content: space-between; align-items: center; }
    nav ul { list-style-type: none; margin: 0; padding: 0; display: flex; }
    nav ul li { margin-right: 20px; }
    nav ul li a { color: white; text-decoration: none; }
    .logout-btn {
        background-color: #f44336;
        color: white;
        border: none;
        padding: 6px 12px;
        cursor: pointer;
        border-radius: 4px;
    }
</head>
<body>